export const POSSIBLE_CATEGORIES = [
    "film_and_tv",
    "music",
    "history",
    "geography",
    "arts_and_literature",
    "sport_and_leisure",
    "general_knowledge",
    "science",
    "food_and_drink"
];
