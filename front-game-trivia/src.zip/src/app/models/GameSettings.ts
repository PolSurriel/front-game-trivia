import { Question } from "./Question";

export class GameSettings {
    id: number;
    difficulty: string;
    questions: Question[];
    categories: string[];
    
}