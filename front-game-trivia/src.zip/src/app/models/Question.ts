import { Answer } from "./Answer";

export class Question {
    category: string;
    text: string;
    answers: Answer[];
    chosenAnswer: number | null;
    correctAnswerId: number | null;
}