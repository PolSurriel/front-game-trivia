export class Answer {
    id: number;
    text: string;
}